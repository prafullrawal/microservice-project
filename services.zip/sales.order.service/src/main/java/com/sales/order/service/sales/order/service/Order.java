package com.sales.order.service.sales.order.service;

import java.util.List;

public class Order {

	private Long customerid;
	private String orderDescription;
	private String orderDate;
	private List<String> itemNames;
	
	
	public Order() {
		// TODO Auto-generated constructor stub
	}
	
	public Order(Long customerid, String orderDescription, String orderDate, List<String> itemNames) {
		super();
		this.customerid = customerid;
		this.orderDescription = orderDescription;
		this.orderDate = orderDate;
		this.itemNames = itemNames;
	}


	public Long getCustomerid() {
		return customerid;
	}
	public void setCustomerid(Long customerid) {
		this.customerid = customerid;
	}
	public String getOrderDescription() {
		return orderDescription;
	}
	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public List<String> getItemNames() {
		return itemNames;
	}
	public void setItemNames(List<String> itemNames) {
		this.itemNames = itemNames;
	}

	@Override
	public String toString() {
		return "Order [customerid=" + customerid + ", orderDescription=" + orderDescription + ", orderDate=" + orderDate
				+ ", itemNames=" + itemNames + "]";
	}
	
}
