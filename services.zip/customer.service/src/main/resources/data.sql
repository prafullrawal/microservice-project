insert into customer (id,first_name,last_name,email) values (101,'customer1','customer1','customer1@abc.com');
insert into customer (id,first_name,last_name,email) values (102,'customer1','customer1','customer1@abc.com');
insert into customer (id,first_name,last_name,email) values (103,'customer1','customer1','customer1@abc.com');