package com.sales.order.service.sales.order.service;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@FeignClient(name = "zuul-edge-server")
@RibbonClient(name = "item.service")
public interface FeignClientService {
	
	@GetMapping("/item.service/Items/{itemName}")
	public Item ItemByName(@PathVariable("itemName") String itemName);
	
}
