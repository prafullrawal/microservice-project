package com.sales.order.service.sales.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ServiceOrderController {
	
	@Autowired
	ServiceOrderRepository serviceOrderRepository;
	
	@GetMapping("/CustomerSOS")
	public List<CustomerSOS> getAllCustomerSOS(){
		return serviceOrderRepository.findAll();
	}

}
