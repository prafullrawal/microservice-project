insert into customer_sos (cust_id, cust_first_name, cust_last_name, cust_email) values (101,'rahul','patel','rahulpatel@abc.com');
