package com.customer.service.customer.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController  {

	@Autowired
	CustomerRepository customerRepository;
	
	private Logger logger = LoggerFactory.getLogger(CustomerController.class);
	 private final RabbitTemplate rabbitTemplate;

	  private final TopicExchange topicExchange;
	  
	@Autowired
	public CustomerController(RabbitTemplate rabbitTemplate, TopicExchange topicExchange) {
	    this.rabbitTemplate = rabbitTemplate;
	    this.topicExchange = topicExchange;
	 }

	
	@GetMapping("/customers")
	public List<Customer> getAllCustomers(){
		return customerRepository.findAll();
	}
	
	@PostMapping("/customer")
	public String createCustomer(@RequestBody Customer customer) {
		customerRepository.save(customer);
		String routingKey = "customer.created";
		rabbitTemplate.convertAndSend(topicExchange.getClass().getName(), routingKey,customer);
		return "CustomerCreated "+customer.toString();
	}

	
}
