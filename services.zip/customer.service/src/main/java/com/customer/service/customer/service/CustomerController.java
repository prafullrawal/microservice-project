package com.customer.service.customer.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@EnableHystrix
public class CustomerController implements ApplicationEventPublisherAware {
	
	private static final Logger log = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	Producer producer;
	@Autowired
	CustomerConfiguration customerConfiguration;
	
	private ApplicationEventPublisher applicationEventPublisher;
	
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		this.applicationEventPublisher = applicationEventPublisher;
	}
	
	@GetMapping("/customers")
	public List<Customer> getAllCustomers(){
		
		log.info("Getting all customer data");
		return customerRepository.findAll();
	}
	
	@PostMapping("/customer")
	public String createCustomer(@RequestBody Customer customer) {
		
		log.info("saving customer to database");
		customer = customerRepository.save(customer);
		
		log.info("Producing & publishing event to rabbitmq");
		producer.produce(customer);
		applicationEventPublisher.publishEvent(customer);
		return "CustomerCreated "+customer.toString();
	}
	
	@GetMapping("/customer/fault-tolerance")
	@HystrixCommand(fallbackMethod = "faultToleranceCallBack")
	public Customer getCustomerFaultTolerance() {
		throw new RuntimeException("Hystrix Example");
	}
	
	@GetMapping("/customer/faultToleranceCallBack")
	public Customer faultToleranceCallBack() {
		return new Customer(11, customerConfiguration.getDefaultfirst_name(), customerConfiguration.getDefaultlast_name(), "email");
	}

}
