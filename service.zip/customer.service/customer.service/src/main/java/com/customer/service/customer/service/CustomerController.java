package com.customer.service.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController implements ApplicationEventPublisherAware {

	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	Producer producer;
	
	private ApplicationEventPublisher applicationEventPublisher;
	
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		this.applicationEventPublisher = applicationEventPublisher;
	}
	
	@GetMapping("/customers")
	public List<Customer> getAllCustomers(){
		return customerRepository.findAll();
	}
	
	@PostMapping("/customer")
	public String createCustomer(@RequestBody Customer customer) {
		
		//saving customer to database
		customerRepository.save(customer);
		
		// Producing event
		producer.produce(customer);
		
		applicationEventPublisher.publishEvent(customer);
		return "CustomerCreated "+customer.toString();
	}

	
}
