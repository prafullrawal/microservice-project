package com.customer.service.customer.service;

import java.util.List;

import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController  {

	
	@Autowired
	CustomerRepository customerRepository;
	
	RabbitTemplate rabbitTemplate = new RabbitTemplate();
	TopicExchange topicExchange = new TopicExchange("New Event");
	
	EventPublisher eventPublisher = new EventPublisher(rabbitTemplate, topicExchange);
	

	@GetMapping("/customers")
	public List<Customer> getAllCustomers(){
		return customerRepository.findAll();
	}
	
	@PostMapping("/customer")
	public String createCustomer(@RequestBody Customer customer) {
		customerRepository.save(customer);
		eventPublisher.sendMessage();
		return "CustomerCreated "+customer.toString();
	}

	
}
