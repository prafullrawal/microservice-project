package com.sales.order.service.sales.order.service;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceOrderRepository extends JpaRepository<CustomerSOS, Long> {
	
	public CustomerSOS findById(long id);
	
}
