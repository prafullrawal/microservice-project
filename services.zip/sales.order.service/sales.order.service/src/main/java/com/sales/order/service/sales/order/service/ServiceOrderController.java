package com.sales.order.service.sales.order.service;

import org.springframework.web.bind.annotation.RestController;


@RestController
public class ServiceOrderController {
	


}
