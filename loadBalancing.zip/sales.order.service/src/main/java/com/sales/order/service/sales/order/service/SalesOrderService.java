package com.sales.order.service.sales.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SalesOrderService {

	@Autowired
	ServiceOrderRepository serviceOrderRepository;
	@Autowired
	SalesOrderRepository salesOrderRepository;
	@Autowired
	FeignClientService feignClientService;
	@Autowired
	OrderLineItemRepository orderLineItemRepository;
	
	public String creatOrder(Order order) throws Exception {
		
		long id = order.getCustomerid();
		
		try {
			CustomerSOS customerSOS =  serviceOrderRepository.findById(id);
			if (customerSOS == null) {
				throw new Exception("No customer found with id :"+  id);
			}
		} catch (Exception e) {
			throw new Exception("No customer found with id :"+  id);
		}
		
		
		List<String> itemName = order.getItemNames();
		int totalPrice = 0;
		
		for (String name : itemName) {
			
			try {
				totalPrice +=  feignClientService.ItemByName(name).getPrice();
			} catch (Exception e) {
					throw new Exception("Item not found in record with name :"+name);
			}
		}
		
		
		  // prepare SalesOrder
		  SalesOrder salesOrder = new SalesOrder();
		  salesOrder.setCust_id(order.getCustomerid());
		  salesOrder.setOrder_date(order.getOrderDate());
		  salesOrder.setOrder_desc(order.getOrderDescription());
		  salesOrder.setTotal_price(totalPrice);
		  
		  salesOrder =  salesOrderRepository.save(salesOrder);
		 
		  for (String itemsName : itemName) {
			//prepare order_line_item 
			  OrderLineItem orderLineItem = new OrderLineItem();
			  orderLineItem.setItem_name(itemsName);
			  orderLineItem.setOrder_id(salesOrder.getId());
			  orderLineItem.setItem_quantity(1);
			
			  orderLineItem = orderLineItemRepository.save(orderLineItem);
		  }
		  
		return "Order ID : "+salesOrder.getId();
	}

	public Item RibbonLoadBalancing() {
		return feignClientService.ItemByName("Item1");
	}
	
}
