package com.sales.order.service.sales.order.service;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SalesOrder {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "order_date")
	private String order_date;
	@Column(name = "cust_id")
	private long cust_id;
	@Column(name = "order_desc")
	private String order_desc;
	@Column(name = "total_price")
	private int total_price;
	
	public SalesOrder() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public SalesOrder(int id, String order_date, int cust_id, String order_desc, int total_price) {
		super();
		this.id = id;
		this.order_date = order_date;
		this.cust_id = cust_id;
		this.order_desc = order_desc;
		this.total_price = total_price;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getOrder_date() {
		return order_date;
	}
	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}
	public long getCust_id() {
		return cust_id;
	}
	public void setCust_id(long cust_id) {
		this.cust_id = cust_id;
	}
	public String getOrder_desc() {
		return order_desc;
	}
	public void setOrder_desc(String order_desc) {
		this.order_desc = order_desc;
	}
	public int getTotal_price() {
		return total_price;
	}
	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}

	@Override
	public String toString() {
		return "SalesOrder [id=" + id + ", order_date=" + order_date + ", cust_id=" + cust_id + ", order_desc="
				+ order_desc + ", total_price=" + total_price + "]";
	}
	
	
	

}
