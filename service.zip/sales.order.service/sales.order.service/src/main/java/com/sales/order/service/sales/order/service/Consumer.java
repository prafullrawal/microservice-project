package com.sales.order.service.sales.order.service;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class Consumer {
	
	@Autowired
	ServiceOrderRepository serviceOrderRepository;
	
	@RabbitListener(queues="${jsa.rabbitmq.queue}", containerFactory="jsaFactory")
    public void recievedMessage(Customer customer) {
        System.out.println("Inserting into Customer_SOS,Recieved Message: " + customer);
        CustomerSOS customerSOS = new CustomerSOS(customer.getId(),customer.getFirst_name(),customer.getLast_name(),customer.getEmail());
        serviceOrderRepository.save(customerSOS);
        System.out.println("Saved into database CustomerSOS"+ customerSOS.toString());
    }
}