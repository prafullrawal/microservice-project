package com.sales.order.service.sales.order.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class ServiceOrderController {
	

	@GetMapping("/success")
	public String getAllCustomers(){
		return "Success";
	}
	
	private Logger logger = LoggerFactory.getLogger(ServiceOrderController.class);

	  public void receive(String message) {
	    logger.info("Received message '{}'", message);
	  }

}
