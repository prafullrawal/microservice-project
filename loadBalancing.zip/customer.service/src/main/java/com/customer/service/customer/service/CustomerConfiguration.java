package com.customer.service.customer.service;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "customer-service")
@Component
public class CustomerConfiguration {
	
	private String defaultfirst_name;
	private String defaultlast_name;
	
	public String getDefaultfirst_name() {
		return defaultfirst_name;
	}
	public void setDefaultfirst_name(String defaultfirst_name) {
		this.defaultfirst_name = defaultfirst_name;
	}
	public String getDefaultlast_name() {
		return defaultlast_name;
	}
	public void setDefaultlast_name(String defaultlast_name) {
		this.defaultlast_name = defaultlast_name;
	}
	
}
