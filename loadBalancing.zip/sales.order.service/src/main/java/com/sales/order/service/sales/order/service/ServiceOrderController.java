package com.sales.order.service.sales.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ServiceOrderController {
	
	@Autowired
	ServiceOrderRepository serviceOrderRepository;
	@Autowired
	SalesOrderService salesOrderService;
	
	
	@GetMapping("/CustomerSOS")
	public List<CustomerSOS> getAllCustomerSOS(){
		return serviceOrderRepository.findAll();
	}
	
	@PostMapping("/orders")
	public String createOrder(@RequestBody Order order) throws Exception {
		return salesOrderService.creatOrder(order);
		
	}
	
	@GetMapping("/RibbonLoadBalancing")
	public Item RibbonLoadBalancing(){
		return salesOrderService.RibbonLoadBalancing();
	}

}
